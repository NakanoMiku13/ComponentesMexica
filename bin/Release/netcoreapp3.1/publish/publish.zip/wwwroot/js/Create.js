﻿$("btnNuevo").click(function (eve) {
    $("#modal-content").load("/Componentes/Create");
});